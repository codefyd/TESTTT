window.APP_CONFIG = {
  // ضع هنا رابط الـ Web App بعد نشر Apps Script
  API_URL: 'PASTE_YOUR_APPS_SCRIPT_WEB_APP_URL_HERE'
};
