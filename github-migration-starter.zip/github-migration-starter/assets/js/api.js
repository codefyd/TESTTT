window.Api = {
  async call(action, payload = {}) {
    if (!window.APP_CONFIG?.API_URL || window.APP_CONFIG.API_URL.includes('PASTE_')) {
      throw new Error('ضع رابط Apps Script Web App داخل assets/js/config.js');
    }

    const response = await fetch(window.APP_CONFIG.API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'text/plain;charset=utf-8' },
      body: JSON.stringify({ action, payload })
    });

    const json = await response.json();
    if (!json.success) {
      throw new Error(json.message || 'API Error');
    }
    return json.data;
  }
};
