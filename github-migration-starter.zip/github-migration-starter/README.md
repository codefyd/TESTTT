# GitHub migration starter

هذه أول نسخة جاهزة لبدء نقل الواجهة من Google Apps Script HTML Service إلى GitHub Pages.

## الموجود في الحزمة
- `index.html`
- `assets/css/style.css`
- `assets/js/config.js`
- `assets/js/api.js`
- `assets/js/auth.js`
- `assets/js/dashboard.js`
- `assets/js/bookings.js`
- `assets/js/app.js`
- `Code_API.gs`

## طريقة العمل
1. ارفع ملفات الواجهة إلى مستودع GitHub.
2. فعّل GitHub Pages.
3. أضف محتوى `Code_API.gs` إلى مشروع Apps Script نفسه.
4. انشر Apps Script كـ Web App.
5. انسخ رابط الـ Web App إلى `assets/js/config.js`.

## ما تم نقله فعليًا في هذه النسخة
- تسجيل الدخول
- لوحة التحكم
- التقويم / الحجوزات
- جلب حجوزات يوم محدد

## المرحلة التالية
- نقل الإضافة والتعديل والحذف للحجوزات
- نقل المصروفات
- نقل المشاريع
- نقل الإعدادات والمستخدمين
