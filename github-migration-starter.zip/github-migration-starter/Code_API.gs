/******************************
 GitHub Pages API Bridge for Google Apps Script
 يعتمد على الدوال الحالية الموجودة لديك داخل Code.gs
******************************/

function doPost(e) {
  try {
    const body = JSON.parse((e && e.postData && e.postData.contents) || '{}');
    const action = body.action;
    const payload = body.payload || {};

    let data;

    switch (action) {
      case 'verifyLogin':
        data = verifyLoginCodeV2(payload.code);
        break;

      case 'getDashboardStats':
        data = getDashboardStats();
        break;

      case 'getEvents':
        data = getEvents();
        break;

      case 'getEventsByDate':
        data = getEventsByDate(payload.date);
        break;

      case 'addEvent':
        data = addEvent(payload);
        break;

      case 'updateEvent':
        data = updateEvent(payload);
        break;

      case 'deleteEvent':
        data = deleteEvent(payload.id);
        break;

      case 'getAllUsersData':
        data = getAllUsersData();
        break;

      case 'getSystemSettings':
        data = getSystemSettings();
        break;

      case 'updateSystemSettings':
        data = updateSystemSettings(payload.calendarId, payload.invoiceFolderId, payload.projectSteps || []);
        break;

      default:
        return jsonOut(false, null, 'Unknown action: ' + action);
    }

    return jsonOut(true, data, null);
  } catch (err) {
    return jsonOut(false, null, err && err.message ? err.message : String(err));
  }
}

function jsonOut(success, data, message) {
  return ContentService
    .createTextOutput(JSON.stringify({ success: success, data: data, message: message }))
    .setMimeType(ContentService.MimeType.JSON);
}
